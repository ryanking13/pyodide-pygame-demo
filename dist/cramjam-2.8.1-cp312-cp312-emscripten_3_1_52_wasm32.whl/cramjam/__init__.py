from .cramjam import *

__doc__ = cramjam.__doc__
if hasattr(cramjam, "__all__"):
    __all__ = cramjam.__all__