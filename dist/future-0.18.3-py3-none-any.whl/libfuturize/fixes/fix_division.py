"""
UNFINISHED
For the ``future`` package.

Adds this import line:

    from __future__ import division

at the top so the code runs identically on Py3 and Py2.6/2.7
"""

from libpasteurize.fixes.fix_division import FixDivision
