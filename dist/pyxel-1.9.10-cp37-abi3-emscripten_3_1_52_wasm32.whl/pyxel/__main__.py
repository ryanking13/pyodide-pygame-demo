from . import cli

cli.cli()
