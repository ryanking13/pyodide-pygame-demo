import pygame

from pathlib import Path

class Player:
    position = pygame.Vector2()
    position.xy = 295, 100
    velocity = pygame.Vector2()
    velocity.xy = 3, 0
    acceleration = 0.1
    rightSprite = pygame.image.load(Path(__file__).parent / 'data/gfx/player.png')
    leftSprite = pygame.transform.flip(rightSprite, True, False)
    currentSprite = rightSprite