import pygame

from pathlib import Path

class Button:
    def __init__(self):
        self.price = 3
        self.level = 1   
    sprite = pygame.image.load(Path(__file__).parent / 'data/gfx/button.png')
    typeIndicatorSprite = pygame.image.load(Path(__file__).parent / 'data/gfx/null_indicator.png')
