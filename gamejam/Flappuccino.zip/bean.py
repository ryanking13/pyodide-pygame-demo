import pygame

from pathlib import Path

class Bean: 
    def __init__(self):
        self.sprite = pygame.image.load(Path(__file__).parent / 'data/gfx/bean.png')
        self.position = pygame.Vector2()
        self.position.xy